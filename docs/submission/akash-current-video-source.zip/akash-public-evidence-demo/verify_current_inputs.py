"""Verify frozen inputs and literal film measurements without rerunning science."""
from pathlib import Path
import hashlib,json

p=Path(__file__).resolve().parent
source=json.loads((p/'CURRENT-SOURCE-PROVENANCE.json').read_text())
for r in source['inputs']:
    b=(p/r['render_project_path']).read_bytes()
    assert len(b)==r['bytes']
    assert hashlib.sha256(b).hexdigest()==r['sha256']
facts=json.loads((p/'proofs/current-completed-case/case-facts.json').read_text())
radar=facts['radar']['counts']; optical=facts['optical']['counts']
assert radar['aoi_pixels']==2480036 and radar['assessed_pixels']==1666783
assert radar['unknown_pixels']==813253 and radar['new_water_candidate_pixels']==25237
assert radar['assessed_pixels']+radar['unknown_pixels']==radar['aoi_pixels']
assert optical=={'aoi_pixels':620008,'joint_assessed_pixels':68801,'unknown_pixels':551207,'candidate_pixels':1060}
assert f"{100*optical['joint_assessed_pixels']/optical['aoi_pixels']:.2f}"=='11.10'
assert facts['conditional_scenario_counts']['inside_water_aoi']=={'ambiguous':14,'unmapped':6,'baseline_disconnected':2}
assert facts['local_hazard_accuracy_established'] is False
assert facts['physical_passability_established'] is False
assert facts['full_track_b_requirements_satisfied'] is False
assert facts['native_grids_resampled_or_fused'] is False
receipt=json.loads((p/'proofs/current-completed-case/execution-receipt.json').read_text())
assert receipt['status']=='completed' and len(receipt['stages'])==14
assert all(s['status']=='completed' and s['exit_code']==0 for s in receipt['stages'])
assert f"{receipt['elapsed_seconds']:.2f}"=='171.07'
assert receipt['gpu_used'] is False
acquisition=json.loads((p/'proofs/current-completed-case/optical-acquisition-manifest.json').read_text())
assert acquisition['network_received_body_bytes']==60069247
benchmark=json.loads((p/'proofs/frozen-water-model/final_test-evaluation.json').read_text())
metrics=benchmark['micro_metrics']
assert f"{100*metrics['water_iou']:.2f}"=='43.89'
assert f"{100*metrics['water_precision']:.2f}"=='79.99'
assert f"{100*metrics['water_recall']:.2f}"=='49.30'
captions=json.loads((p/'SUBTITLES.json').read_text())
assert captions['duration']==180 and captions['burned'] is True and captions['narration'] is False
cues=captions['cues']
assert cues[0]['start']==0 and cues[-1]['end']==180
assert all(a['end']==b['start'] for a,b in zip(cues,cues[1:]))
assert all(c['end']>c['start'] and c['text'].strip() for c in cues)
report={'status':'passed','verified_frozen_input_count':len(source['inputs']),'radar_counts':radar,
        'optical_counts':optical,'inside_aoi_access':facts['conditional_scenario_counts']['inside_water_aoi'],
        'completed_stages':len(receipt['stages']),'case_elapsed_seconds':receipt['elapsed_seconds'],
        'new_optical_body_bytes':acquisition['network_received_body_bytes'],
        'frozen_benchmark_metrics':metrics,'english_cues':len(cues),'continuous_subtitle_coverage_seconds':180,
        'science_rerun':False,'new_hazard_validation':False,'human_review':False,'new_backend_execution':False}
(p/'output').mkdir(exist_ok=True)
(p/'output/input-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
