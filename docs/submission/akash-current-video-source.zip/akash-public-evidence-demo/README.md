# Akash public-evidence demo — 13 October 2026

Refreshed 180-second, 1920×1080, 24 fps English-subtitled silent demo. Original 11 October source/movie are preserved outside this isolated copy. HyperFrames was upgraded from 0.8.146 to 0.8.152; the imported composition passed the upgraded full check before authoring.

`build_current_demo.py` authors seven scenes and matching burned/subtitle cues. It requires real current UI capture paths in `ASSET-MAP.json`; no placeholder UI is allowed. `CURRENT-SOURCE-PROVENANCE.json` binds unchanged completed-case maps and receipts; the separate existing benchmark is unchanged. `verify_current_inputs.py` verifies literal numbers and cue continuity without running inference, labels, scientific processing or the satellite backend.

The film explicitly separates saved evidence, actual recorded UI controls and the recorded 12 October integration run. GitHub Pages is a static saved-evidence demo. Radar, elevation and pre-event OSM were cached in that recorded case; only the declared optical requests were new. Native unknown coverage remains visible. Conditional paths/cuts do not establish physical passability. This is an educational prototype.

Build: `python3 build_current_demo.py`, then `python3 verify_current_inputs.py`. Check: `npm run check -- --json`. Open Studio with `npx hyperframes@0.8.152 preview --background`. Render only within the human's existing completion authorization: `npm run render -- --fps 24 --quality delivery --experimental-fast-capture=false --no-browser-gpu --workers=1 --video-frame-format=png --output output/akash-track-b-public-demo-2026-10-13.mp4`.

The complete local render, format/decode/frame QA, source hashes and preview verification are recorded under the dated publication video-receipt folder. No YouTube upload is implied by creating an MP4. Data/vendor/model/library terms remain separate from original code MIT; OpenAI Codex and HyperFrames/GSAP assistance is disclosed. Bundled fonts include their OFL notices. Imported dated provenance files are archived under `historical-import/` and are not current-render receipts.
