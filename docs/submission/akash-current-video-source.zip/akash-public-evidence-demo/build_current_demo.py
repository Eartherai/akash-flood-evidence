"""Author the updated 180 s film from unchanged case evidence and real UI captures."""
from pathlib import Path
from html import escape
import json

p = Path(__file__).resolve().parent
assets = json.loads((p / 'ASSET-MAP.json').read_text())
for role in ('overview', 'access', 'execution', 'sources'):
    assert assets.get(role), f'Actual current UI capture is required: {role}'
    assert (p / assets[role]).is_file(), f'Missing actual UI capture: {assets[role]}'
if assets.get('interaction'):
    assert (p / assets['interaction']).is_file()
    assert 0 < float(assets['interaction_duration']) <= 20

scenes = [
    dict(id='decision', start=0, duration=20, title='Uncertainty changes the answer.',
         deck='AKASH / Flood evidence and access proofs', kind='cover',
         lines=['Map the observations.', 'Test the road assumptions.', 'Keep the evidence.']),
    dict(id='radar', start=20, duration=26, title='Water candidates. Visible limits.',
         deck='Actual saved Rasuwa output / native radar grid', image='assets/map.png',
         lines=['25,237 new-water candidate cells', '1,666,783 / 2,480,036 cells assessed',
                '813,253 cells remain unknown', 'Before 16 Aug / after 28 Aug 2026']),
    dict(id='optical', start=46, duration=26, title='Most optical cells are unknown.',
         deck='Actual saved Sentinel-2 output / native optical grid', image='assets/optical-overview.png',
         lines=['11.10% jointly assessed', '551,207 / 620,008 cells unknown',
                '1,060 provisional change candidates', 'Surface change is not validated debris']),
    dict(id='access', start=72, duration=32, title='Which conclusion survives uncertainty?',
         deck='Actual current browser UI / saved case evidence', image=assets['access'],
         video=assets.get('interaction'), video_duration=assets.get('interaction_duration'),
         lines=['Inside AOI: 14 undetermined', '6 unmapped / 2 baseline disconnected',
                'Fixed targets / open–closed graph bounds', 'No confirmed road closures supplied']),
    dict(id='execution', start=104, duration=28, title='14 stages. One disclosed case.',
         deck='Actual current UI / completed 12 October run receipt', image=assets['execution'],
         lines=['171.07 seconds / CPU processing', 'Verified cached radar, DEM and pre-event OSM',
                '60,069,247 new Sentinel-2 bytes', 'Execution success does not prove map accuracy']),
    dict(id='benchmark', start=132, duration=22, title='A benchmark is not local validation.',
         deck='Frozen Sen1Floods11 water classifier / unchanged', kind='benchmark',
         lines=['43.89% water IoU', '79.99% precision / 49.30% recall',
                'No established Himalayan flood or debris accuracy',
                'Reference damage maps are checking-only']),
    dict(id='release', start=154, duration=26, title='Open the evidence. Run the code locally.',
         deck='Actual current browser UI / GitHub Pages saved-evidence demo', image=assets['overview'],
         lines=['Explore source-bound maps and conditional access',
                'Local console: plan, acquire, process, report',
                'Static website does not run the satellite backend',
                'Open source / original code MIT']),
]
groups = [
    [(0, 6, 'Akash asks what satellite evidence supports, and which road-access conclusions depend on unknowns.'),
     (6, 13, 'It joins before-and-after radar, optical observations, elevation and pre-event OpenStreetMap.'),
     (13, 20, 'Its strongest feature is a conditional access proof: test uncertain roads and keep the evidence.')],
    [(20, 26, 'This actual saved radar map comes from the completed Rasuwa case for 26 August 2026.'),
     (26, 33, 'There are 25,237 newly predicted water candidate cells. They are not confirmed damage.'),
     (33, 39, 'Radar jointly assesses 1,666,783 of 2,480,036 cells; 813,253 remain unknown.'),
     (39, 46, 'Before-and-after processing uses matched radar sources from 16 and 28 August. Local accuracy remains unproved.')],
    [(46, 52, 'The optical layer retains its native grid and its own observation denominator.'),
     (52, 59, 'Only 68,801 of 620,008 cells are jointly assessed: 11.10 percent.'),
     (59, 65, 'A further 551,207 cells remain unknown. Cloud and missing support are not filled with certainty.'),
     (65, 72, 'The 1,060 surface-change candidates use fixed hypotheses. They are not validated debris classifications.')],
    [(72, 80, 'The current browser can inspect saved access evidence. This does not execute a new satellite run.'),
     (80, 88, 'Within this AOI: 14 settlements are undetermined, six unmapped, and two baseline disconnected.'),
     (88, 96, 'The graph fixes baseline targets and checks uncertain road groups under all-open and all-closed scenarios.'),
     (96, 104, 'Witness paths and cut certificates can be checked independently. They do not establish safe passage or observed closures.')],
    [(104, 111, 'The recorded known-case workflow completed all 14 stages in 171.07 seconds on the local computer.'),
     (111, 118, 'Radar, elevation and pre-event OSM were verified cached inputs. This is not a cold-acquisition timing.'),
     (118, 125, 'New Sentinel-2 acquisition received 60,069,247 bytes. Source identities and output receipts remain inspectable.'),
     (125, 132, 'Historical-map provider failures are retained. Arbitrary judge-selected raw-data reliability remains unproved.')],
    [(132, 139, 'The unchanged Sen1Floods11 water benchmark reports 43.89 percent IoU and 79.99 percent precision.'),
     (139, 146, 'Water recall is 49.30 percent. This benchmark does not validate Himalayan flood, debris or infrastructure damage.'),
     (146, 154, 'Earlier EMSR927 comparisons are checking-only, involve different classes and fail internal coverage gates. No accuracy is invented.')],
    [(154, 160, 'Open the public saved-evidence website to inspect maps, source facts and conditional access results.'),
     (160, 167, 'Use the separate local console and documented prerequisites to plan and run bounded satellite processing.'),
     (167, 173, 'The static website does not run that backend or the optional local Qwen copilot.'),
     (173, 180, 'Original code is MIT. Data retains upstream terms. AI assistance is disclosed. This is an educational evidence prototype.')],
]
cues = [dict(start=a, end=b, text=c, frame=s['id']) for s, g in zip(scenes, groups) for a, b, c in g]
assert scenes[-1]['start'] + scenes[-1]['duration'] == 180
assert cues[0]['start'] == 0 and cues[-1]['end'] == 180
assert all(a['end'] == b['start'] for a, b in zip(cues, cues[1:]))
def tc(t):
    return f'{int(t)//3600:02}:{int(t)%3600//60:02}:{int(t)%60:02},000'
(p/'SUBTITLES.json').write_text(json.dumps({'language':'en','duration':180,'burned':True,'narration':False,'cues':cues},indent=2)+'\n')
(p/'subtitles.srt').write_text('\n\n'.join(f'{i}\n{tc(c["start"])} --> {tc(c["end"])}\n{c["text"]}' for i,c in enumerate(cues,1))+'\n')

font = """@font-face{font-family:'Source Serif 4';src:url('assets/fonts/SourceSerif4.woff2') format('woff2');font-weight:400 600;font-display:block;}@font-face{font-family:'JetBrains Mono';src:url('assets/fonts/JetBrainsMono.woff2') format('woff2');font-weight:400 600;font-display:block;}"""
css = """*{box-sizing:border-box}#root{position:absolute;inset:0;width:100%;height:100%;overflow:hidden;container-type:size;background:#efe7d4;color:#243a21}.topbar{position:absolute;left:80px;right:80px;top:46px;height:70px;border-bottom:2px solid currentColor;display:flex;justify-content:space-between;font:500 23px/1.2 'JetBrains Mono';letter-spacing:.08em;text-transform:uppercase}.body{position:absolute;left:80px;right:80px;top:145px;bottom:205px;display:grid;grid-template-columns:1040px 1fr;gap:50px;align-items:center}.media{margin:0;width:1040px;height:650px;display:flex;align-items:center;justify-content:center;border:2px solid #243a21;background:#e6dcc4;border-radius:6px;overflow:hidden}.media img{display:block;width:100%;height:100%;object-fit:contain}h1{margin:0;font:500 62px/1.05 'Source Serif 4';letter-spacing:-.02em}.deck{font:500 21px/1.4 'JetBrains Mono';letter-spacing:.02em;margin:24px 0 26px}.lines{margin:0;padding:0;display:flex;flex-direction:column;gap:20px;list-style:none}.line{font:400 34px/1.19 'Source Serif 4';margin:0;padding-top:12px;border-top:2px solid #243a21}.line span{display:block;width:100%}.full{grid-template-columns:1fr}.full h1{font-size:116px;max-width:1600px}.full .deck{font-size:27px}.full .lines{display:grid;grid-template-columns:1fr 1fr;gap:28px 70px;margin-top:48px}.full .line{font-size:46px}.cover .lines{display:flex;flex-direction:row;justify-content:space-between}.cover .line{font-size:48px;border-color:#efe7d4}.video-panel{position:absolute;left:80px;top:145px;width:1040px;height:650px;object-fit:contain;background:#e6dcc4;border:2px solid #243a21}.video-body{left:1170px;display:block}.video-body .line{font-size:34px}.citation{position:absolute;left:80px;right:80px;top:838px;font:400 19px/1.4 'JetBrains Mono';margin:0;letter-spacing:0}.benchmark .line:first-child{font-size:70px}.release-url{font:500 18px/1.2 'JetBrains Mono';margin:16px 0 0;overflow-wrap:anywhere;}"""
for directory in ['compositions/frames','compositions/captions']:
    d=p/directory; d.mkdir(parents=True,exist_ok=True)
    for f in d.glob('*.html'): f.unlink()
hosts=[]; caps=[]
for idx,s in enumerate(scenes,1):
    cid=s['id']; duration=s['duration']; klass='';media=''
    if 'image' in s:
        media=f'<figure class="media"><img src="{escape(s["image"])}" alt="Actual saved source-bound evidence"></figure>'
    if cid in ('radar', 'optical'):
        legend = ([('#C1C8CF', 'Unknown'), ('#EDF2EE', 'Assessed, no water candidate'),
                   ('#99BBB8', 'Water on both dates'), ('#087E82', 'New-water candidate'),
                   ('#D87C43', 'Lost-water candidate')] if cid == 'radar' else
                  [('#c1c8cf', 'Unknown'), ('#e8f0e6', 'Assessed, no candidate'),
                   ('#934e23', 'Surface-change candidate')])
        legend_markup=''.join(f'<p><i style="background:{color}"></i><span>{escape(label)}</span></p>' for color,label in legend)
        spacing = '10 m radar grid' if cid == 'radar' else '20 m optical grid'
        media=f'<figure class="media native"><img src="{escape(s["image"])}" alt="Unchanged actual native-grid classification image"><figcaption><strong>{spacing}</strong>{legend_markup}<small>North approximately up. AOI: 85.30–85.42 E, 28.12–28.31 N.</small></figcaption></figure>'
    if s.get('kind') in ('cover','benchmark'): klass='full '+s['kind']
    lines=''.join(f'<li id="{cid}-line-{i}" class="line"><span>{escape(line)}</span></li>' for i,line in enumerate(s['lines']))
    if s.get('video'):
        vd=float(s['video_duration'])
        media=f'<video id="{cid}-recording" class="clip video-panel" src="{escape(s["video"])}" muted playsinline data-start="0" data-duration="{vd}" data-track-index="1"></video>'
        media+=f'<figure id="{cid}-recorded-state" class="clip media" style="position:absolute;left:80px;top:145px" data-start="{vd}" data-duration="{duration-vd}" data-track-index="1"><img src="{escape(s["image"])}" alt="Actual current UI after the interaction"></figure>'
        content=f'{media}<div class="body video-body"><div><h1 id="{cid}-title">{escape(s["title"])}</h1><p class="deck">{escape(s["deck"])}</p><ul class="lines">{lines}</ul></div></div>'
    else:
        content=f'<div class="body {klass}">{media}<div><h1 id="{cid}-title">{escape(s["title"])}</h1><p class="deck">{escape(s["deck"])}</p><ul class="lines">{lines}</ul>'
        # The public URL lives in the full-width citation rail, avoiding column overflow.
        content+='</div></div>'
    citation='Actual case evidence / 12 October 2026. Presentation updated 13 October. Educational prototype.'
    if cid=='release':citation='Public demo: https://eartherai.github.io/akash-flood-evidence/  |  Original code MIT. AI: OpenAI Codex.'
    content+=f'<p class="citation">{escape(citation)}</p>'
    scene_css=css+""".native{display:grid;grid-template-columns:400px 1fr;gap:28px;padding:18px 28px;background:#f7f4eb}.native img{width:100%;height:610px;object-fit:contain}.native figcaption{font:400 29px/1.2 'Source Serif 4';padding-right:15px}.native figcaption strong{display:block;font-size:35px;margin-bottom:25px}.native figcaption p{display:flex;gap:18px;align-items:center;margin:18px 0}.native figcaption i{flex:none;width:27px;height:27px;border:1px solid #526052}.native figcaption small{display:block;font:400 20px/1.4 'JetBrains Mono';margin-top:30px}"""+('#root{background:#2e4a2a;color:#efe7d4}' if s.get('kind')=='cover' else '')
    # Retain the original film's restrained opacity and small title-y entrance.
    anim=f'''const t=gsap.timeline({{paused:true}});t.fromTo("#{cid}-title",{{opacity:0,y:10}},{{opacity:1,y:0,duration:.55,ease:'power3.out'}},0);'''
    for i in range(len(s['lines'])):
        at=2+i*min(2.3,(duration-6)/len(s['lines']))
        anim+=f'''t.fromTo("#{cid}-line-{i} span",{{opacity:0}},{{opacity:1,duration:.6,ease:'power2.out'}},{at:.3f});'''
    anim+=f"window.__timelines['{cid}']=t;"
    (p/f'compositions/frames/{cid}.html').write_text(f'<template><style>{font}{scene_css}</style><div id="root" data-composition-id="{cid}" data-width="1920" data-height="1080" data-duration="{duration}"><div class="topbar"><span>AKASH / EVIDENCE, NOT CERTAINTY</span><span>{idx:02d} / 07</span></div>{content}</div><script>{anim}</script></template>')
    hosts.append(f'<div id="{cid}-host" class="clip scene" data-composition-id="{cid}" data-composition-src="compositions/frames/{cid}.html" data-start="{s["start"]}" data-duration="{duration}" data-track-index="0" data-width="1920" data-height="1080"></div>')
    cc=f'caption-{idx:02d}';cs=[c for c in cues if c['frame']==cid]
    capcss="""#root{position:absolute;inset:0;width:100%;height:100%;overflow:hidden}.band{position:absolute;left:0;top:908px;width:1920px;height:172px;display:flex;align-items:center;justify-content:center;background:#243a21;color:#efe7d4;margin:0;padding:24px 85px 30px;font:400 35px/1.25 'Source Serif 4';text-align:center;}"""
    cp=''.join(f'<p class="clip band" id="{cc}-{j:02d}" data-start="{c["start"]-s["start"]}" data-duration="{c["end"]-c["start"]}" data-track-index="{1+j%2}" data-layout-allow-caption-zone>{escape(c["text"])}</p>' for j,c in enumerate(cs))
    (p/f'compositions/captions/{cc}.html').write_text(f'<template><style>{font}{capcss}</style><div id="root" data-composition-id="{cc}" data-width="1920" data-height="1080" data-duration="{duration}">{cp}</div><script>window.__timelines["{cc}"]=gsap.timeline({{paused:true}});</script></template>')
    caps.append(f'<div id="{cc}-host" class="clip captions" data-composition-id="{cc}" data-composition-src="compositions/captions/{cc}.html" data-start="{s["start"]}" data-duration="{duration}" data-track-index="1" data-width="1920" data-height="1080"></div>')
(p/'index.html').write_text(f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Akash / Flood evidence and access proofs</title><script src="assets/gsap.min.js"></script><style>html,body{{margin:0;background:#243a21}}*{{box-sizing:border-box}}#root{{position:absolute;inset:0;width:100%;height:100%;overflow:hidden}}.scene,.captions{{position:absolute;inset:0;width:100%;height:100%}}.captions{{z-index:90}}#progress{{position:absolute;left:80px;bottom:12px;width:1760px;height:3px;background:#e89cb1;transform-origin:left center;z-index:100}}</style></head><body><div id="root" data-composition-id="main" data-width="1920" data-height="1080" data-duration="180">{''.join(hosts)}{''.join(caps)}<div id="progress" data-layout-ignore></div></div><script>const main=gsap.timeline({{paused:true}});main.fromTo('#progress',{{scaleX:0}},{{scaleX:1,duration:180,ease:'none'}},0);window.__timelines.main=main;</script></body></html>''')
(p/'CURRENT-STORYBOARD.json').write_text(json.dumps({'duration':180,'frames':scenes,'cues':cues},indent=2)+'\n')
(p/'STORYBOARD.md').write_text('# Refreshed Akash public-evidence film / 13 October 2026\n\n180 seconds, seven scenes, silent with complete English subtitles. The original film is preserved. Actual maps and browser captures are unchanged; browser interaction is recorded and explicitly reviews saved evidence. No scientific processing or new accuracy evaluation occurs in this render.\n\n'+'\n\n'.join(f'## {i}. {s["title"]}\n\n{s["start"]}–{s["start"]+s["duration"]} seconds. '+s['deck']+'.\n\n'+'\n'.join(s['lines']) for i,s in enumerate(scenes,1))+'\n')
print(f'Built seven scene and seven caption compositions / {len(cues)} continuous English cues / 180 seconds')
